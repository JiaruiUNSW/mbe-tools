# TODO

- [x] Implement connectivity-based fragmentation (P3)
- [x] Add pattern labels and ion detection (P3)
- [x] Add tests for connectivity and labels (P3)
